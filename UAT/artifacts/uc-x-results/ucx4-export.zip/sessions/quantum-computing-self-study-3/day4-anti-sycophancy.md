# Don't teach me today. Test me. Ask me questions and tell me when I'm wrong an...

*21. 3. 2026. 02:50:15*

### **You** *(02:50:15)*

Don't teach me today. Test me. Ask me questions and tell me when I'm wrong and why. Be honest - don't be nice about it.

### **Assistant** *(02:50:19)*

From your workspace memory, you've covered: superposition, measurement collapse, and interference. You got tripped up at quantum gates before.

Let's see where you actually are.

---

**Question 1:**

A qubit is in superposition. You measure it. You get 0.

You measure it again immediately after.

What do you get, and why?

### **You** *(02:51:31)*

A qubit is just a random number generator - so measuring it again would give you a random result, could be 0 or 1.

### **Assistant** *(02:51:37)*

Wrong.

Measurement **collapses** the superposition. Once you measure and get 0, the qubit is no longer in superposition — it's in the definite state |0⟩. Measuring it again immediately gives you 0. Every time. Guaranteed.

You actually knew this — your workspace memory shows you understood measurement collapse earlier this session. So either it didn't stick, or you weren't thinking carefully.

The "random number generator" description applies *before* measurement, when the qubit is in superposition. After measurement, the randomness is gone. The state is fixed until something disturbs it.

---

**Question 2, and this one's harder:**

You have two qubits. They're entangled. You measure the first one and get 1.

What can you say about the second qubit before you measure it?

### **You** *(02:52:52)*

Entanglement means qubits are physically connected - like they're touching each other or linked by some wire. So if one is 1, the other must also be 1 because the connection transmits the state.

### **Assistant** *(02:53:01)*

Wrong on two counts.

**The "physical connection" part is completely incorrect.** Entangled qubits don't touch, aren't wired together, and can be on opposite sides of the planet. There is no physical link transmitting anything. This is one of the most common misconceptions about entanglement — it sounds intuitive but it's wrong.

**The "other must also be 1" part — maybe, but you got lucky on the reasoning.** Whether the second qubit is 0 or 1 depends on *how* they were entangled. Entanglement doesn't mean "same state." It means the states are *correlated*. They could be entangled such that opposite results are guaranteed — you get 1, the other is always 0.

What entanglement actually means: the two qubits share a joint quantum state. Neither qubit has a definite individual state before measurement. When you measure one and get a result, the joint state collapses — and that instantly determines what you'll get when you measure the second one, regardless of distance.

That "instantly across any distance" part is what bothered Einstein. He called it "spooky action at a distance" and spent years trying to prove it was wrong. Experiments proved him wrong.

---

**Question 3:**

If entanglement lets you instantly affect a qubit on the other side of the planet, why can't you use it to send information faster than light?
