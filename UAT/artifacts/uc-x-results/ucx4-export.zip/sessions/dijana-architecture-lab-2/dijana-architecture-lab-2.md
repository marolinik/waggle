# What can you actually do right now? List every tool you have access to, group...

*21. 3. 2026. 02:40:17*

### **You** *(02:40:17)*

What can you actually do right now? List every tool you have access to, grouped by category, with a one-line description of each.

### **Assistant** *(02:40:43)*

Here's every tool I have access to right now, grouped by category:

---

## Memory
- **search_memory** — Recall past decisions, context, preferences from my persistent .mind file
- **save_memory** — Store new facts, decisions, corrections for future sessions
- **get_identity** — Retrieve my role, name, and capabilities
- **get_awareness** — Check active tasks, flags, and pending items
- **query_knowledge** — Query the knowledge graph for entities and relationships
- **search_all_workspaces** — Search across ALL workspaces + personal memory simultaneously
- **add_task** — Add a task to my awareness tracking layer
- **correct_knowledge** — Fix or invalidate a knowledge graph entity

---

## File System
- **read_file** — Read file contents (partial reads supported)
- **write_file** — Create or overwrite a file
- **edit_file** — Surgical string replacement in a file
- **multi_edit** — Apply multiple atomic edits across one or more files
- **search_files** — Find files by glob pattern
- **search_content** — Regex search through file contents with context lines

---

## Shell / System
- **bash** — Execute shell commands (supports background processes)
- **get_task_output** — Check output of a running background task
- **kill_task** — Stop a background task
- **cli_discover** — List available CLI tools on the system
- **cli_execute** — Run allowlisted CLI programs (gh, aws, docker, etc.)

---

## Git
- **git_status** — Show modified/untracked files and current branch
- **git_diff** — Show unstaged or staged diffs
- **git_log** — Show recent commit history
- **git_commit** — Stage files and create a commit

---

## Web & Research
- **web_search** — Search DuckDuckGo for current info
- **web_fetch** — Fetch and read any URL
- **tavily_search** — AI-optimized web search via Tavily (requires API key)
- **brave_search** — Brave Search with freshness filtering (requires API key)

---

## Browser Automation
- **browser_navigate** — Navigate to a URL in a browser session
- **browser_screenshot** — Capture a screenshot of the current page
- **browser_click** — Click an element by CSS selector
- **browser_fill** — Fill an input field by CSS selector
- **browser_evaluate** — Run JavaScript in the current page context
- **browser_snapshot** — Get an accessibility-tree DOM snapshot

---

## Documents
- **generate_docx** — Create formatted Word (.docx) files from markdown

---

## Language Server (Code Intelligence)
- **lsp_diagnostics** — Get TypeScript/JS errors for a file
- **lsp_definition** — Jump to the definition of a symbol
- **lsp_references** — Find all references to a symbol
- **lsp_hover** — Get type info and docs for a symbol at a position

---

## Planning
- **create_plan** — Create a structured multi-step execution plan
- **add_plan_step** — Add a step to the current plan
- **execute_step** — Mark a plan step complete with a result
- **show_plan** — Display the current plan with step statuses

---

## Skills & Capabilities
- **list_skills** — Show all installed skills (I have 56 loaded)
- **create_skill** — Create a new persistent skill from a workflow description
- **delete_skill** — Remove an installed skill
- **read_skill** — Read the full content of a skill
- **search_skills** — Search installed skills and built-in capabilities
- **suggest_skill** — Get contextual skill recommendations for the current task
- **acquire_capability** — Detect gaps and find installable skills to fill them
- **install_capability** — Install a skill from the starter pack (requires your approval)

---

## Sub-Agents & Orchestration
- **spawn_agent** — Spawn a specialist sub-agent (researcher, coder, writer, reviewer, etc.)
- **list_agents** — Show active and completed sub-agents
- **get_agent_result** — Retrieve a completed sub-agent's full output
- **compose_workflow** — Analyze a task and get the optimal execution approach
- **orchestrate_workflow** — Run a multi-agent workflow (research-team, review-pair, plan-execute)

---

## Scheduling
- **create_schedule** — Create a cron job (supports standard expressions and shorthands)
- **list_schedules** — View all scheduled jobs and next run times
- **delete_schedule** — Remove a schedule by name
- **trigger_schedule** — Manually fire a schedule immediately

---

**Total: 57 tools + 56 loaded skills.** If there's something specific you need done, I either have a tool for it or can acquire a skill for it.

### **You** *(02:41:16)*

Based on my usage pattern in this workspace, what capabilities would make me more productive that I don't currently have installed?

### **Assistant** *(02:41:49)*

Good, I have everything I need. Here's an honest, evidence-based assessment:

---

## Capability Gaps Based on Your Actual Usage

I looked at: your active tasks (M4 Tauri, B2B banking lead gen, M5 web app), your workspace history across Egzakta client work, your stated preferences, and the 56 skills already installed.

### 1. Architectural Review Companion — **You asked for this explicitly**
- **Evidence:** You stated in a previous session: *"I want a skill that reviews code diffs against documented team conventions, flags decisions conflicting with known architectural patterns, generates review comments, and saves patterns as persistent memory."*
- **Gap:** Not installed. You have generic `code-review` but nothing that cross-references your specific Waggle architectural decisions.
- **Value:** High. You're entering M4 (Tauri) — a significant architectural shift. This would catch drift from your established patterns.

### 2. B2B Sales / Lead Gen Workflow Skill
- **Evidence:** Active task: *"Set up B2B banking lead generation and sales workflow framework."* You have Egzakta with banking/telco/government clients and global expansion targets (Benelux, Germany, UAE).
- **Gap:** Nothing installed for structured sales workflows, ICP definition, outreach sequencing, or CRM pipeline design. The `klaviyo` skill is email marketing, not B2B sales.
- **Value:** High. This is an active, unresolved task right now.

### 3. Tauri / Desktop App Development Skill
- **Evidence:** M4 is your immediate next milestone — Tauri 2.0, Windows first.
- **Gap:** You have `senior-devops`, `frontend-design`, `web-design-guidelines` — nothing specific to Tauri, Rust/WebView2 integration, or Windows packaging/signing workflows.
- **Value:** High. Tauri 2.0 has significant breaking changes from 1.x. A skill with the right patterns would save real time.

### 4. Client Deliverable / Proposal Generator
- **Evidence:** You run client projects (Ministry of Finance AI Strategy, RetailCo Digital Transformation) and are expanding Egzakta into new markets. You've used `generate_docx` and `draft-memo` before.
- **Gap:** No skill for structured consulting deliverables — client proposals, engagement letters, executive briefings with Egzakta branding context baked in.
- **Value:** Medium-high. The `draft-memo` skill is generic; you need something that knows Egzakta's service areas, Five Pillars, and formats.

### 5. Milestone Tracker / Sprint Planner
- **Evidence:** You track work in milestone format (M1–M5), with numbered task lists and clear done/next/later states. You've completed M1, M2, M3a, M3b, M3c.
- **Gap:** No persistent skill for milestone planning that understands your M-numbering system and saves progress automatically as tasks complete.
- **Value:** Medium. You manage this manually now; a skill would give it structure and memory persistence.

---

## What I'd Prioritize

| Priority | Skill | Why Now |
|---|---|---|
| 1 | **Architectural Review Companion** | You asked for it; M4 starts next |
| 2 | **B2B Sales Workflow** | Active unresolved task |
| 3 | **Tauri 2.0 Dev Skill** | M4 is your next milestone |
| 4 | **Client Deliverable Generator** | Recurring need across Egzakta workspaces |
| 5 | **Milestone Tracker** | Nice-to-have, low urgency |

---

The first three I can create right now — they don't exist in the marketplace so I'd build them as custom skills tailored to your specific context. Want me to start with the Architectural Review Companion since that was your explicit request?

### **You** *(02:44:20)*

I want to create a new skill called 'Architectural Review Companion'. It should review code diffs against documented team conventions, flag decisions conflicting with known architectural patterns, generate review comments in the team's communication style, and save 'patterns we follow' as persistent memory. Help me design and write the skill definition file.

### **Assistant** *(02:45:29)*

Done. Here's what was built and why each decision was made:

---

## What's in the Skill

**Hardcoded baseline** — 10 architectural patterns pulled directly from your memory, not generic best practices:
- CognifyPipeline wiring (the critical bug you already hit)
- FTS5 hyphen sanitization (the exact bug fixed in `search.ts`)
- `runAgentLoop()` as the single execution path
- `ConfirmationGate` for destructive tools
- MindDB portability constraint (no external state stores)
- All 5 others grounded in your actual decisions

**Structured checklist** per review — structural, memory system, agent loop, safety, and test checks. Each maps to a real failure mode you've already encountered.

**Comment format with severity tiers:**
- 🔴 Blocker — don't merge
- 🟡 Should fix — before next milestone
- 🔵 Suggestion — optional improvement

**Auto-persist new patterns** — if a review uncovers a convention that isn't in memory yet, the skill saves it. Your pattern library grows with every review.

**Quick commands** for common workflows — "review current changes", "review staged changes", "what patterns do we follow?"

---

## Try It Now

With M4 (Tauri) starting next, you could run:

> "Review current changes" — and I'll run `git_diff`, check everything against the baseline, and give you a full structured review.

### **You** *(02:46:49)*

Save this skill to my skills directory so I can install it.

### **Assistant** *(02:46:59)*

Confirmed. The skill is fully installed and active — loaded into my system prompt and persisted across all future sessions.

**What's confirmed:**
- Name: `architectural-review-companion`
- Content: Complete, with your exact stack, all 10 patterns, the structured checklist, severity tiers, and quick commands
- Status: Hot-loaded — available right now, no restart needed

**To use it immediately**, just say any of:
- *"Review current changes"*
- *"Review staged changes"*
- *"What patterns do we follow?"*
- *"Check [feature] against architecture"*

Ready for M4 whenever you are.

### **You** *(02:47:51)*

Review the diff from git log HEAD~1 (commit c0078fc) for architectural alignment. Just give me a quick review.

### **You** *(02:51:31)*

Review just the code changes in packages/server/src/local/routes/chat.ts and packages/agent/src/personas.ts from the latest commit for architectural alignment. Quick review only.

### **Assistant** *(02:52:58)*

Blocked by the ConfirmationGate — you denied the bash command. I can't pull the diff without running git in your repo.

Two options:

1. **Paste the diff here** — run `git diff HEAD~1 HEAD` yourself in `D:\Projects\MS Claw\waggle-poc` and paste the output. I'll review it immediately.
2. **Approve the command** — allow the bash call and I'll pull and review in one shot.

Which do you prefer?
