# What can you actually do right now? List every tool you have access to, group...

*21. 3. 2026. 02:43:30*

### **You** *(02:43:30)*

What can you actually do right now? List every tool you have access to, grouped by category.

### **Assistant** *(02:43:54)*

Here's everything I can actually do right now, grouped by category:

---

## Memory & Knowledge
- **search_memory** — Search past decisions, context, and facts (workspace + personal)
- **save_memory** — Persist new knowledge to workspace or personal mind
- **get_identity** — Who I am, my role and capabilities
- **get_awareness** — Current tasks, active flags, pending items
- **query_knowledge** — Query the knowledge graph for entities and relationships
- **correct_knowledge** — Fix or invalidate a knowledge entity
- **add_task** — Track a task in my awareness layer
- **search_all_workspaces** — Search across ALL workspaces simultaneously

---

## File System
- **read_file** — Read file contents (with offset/limit support)
- **write_file** — Create or overwrite a file
- **edit_file** — Surgical string replacement in a file
- **multi_edit** — Atomic multi-file edits in one operation
- **search_files** — Find files by glob pattern
- **search_content** — Regex search through file contents

---

## Shell & System
- **bash** — Run shell commands (background mode supported)
- **get_task_output** — Get output from a background bash task
- **kill_task** — Kill a running background task
- **cli_discover** — Discover available CLI tools on the system
- **cli_execute** — Run allowlisted CLI programs (gh, aws, docker, etc.)

---

## Git
- **git_status** — Show modified/untracked files and current branch
- **git_diff** — Show unstaged or staged changes
- **git_log** — Show recent commits
- **git_commit** — Stage files and create a commit

---

## Web & Research
- **web_search** — Search DuckDuckGo for current info
- **web_fetch** — Fetch and read any URL
- **tavily_search** — AI-optimized search via Tavily (requires API key)
- **brave_search** — Brave Search with freshness filtering (requires API key)

---

## Browser Automation
- **browser_navigate** — Navigate to a URL in a real browser
- **browser_screenshot** — Capture the current page
- **browser_click** — Click elements by CSS selector
- **browser_fill** — Fill form inputs
- **browser_evaluate** — Run JavaScript on the page
- **browser_snapshot** — Get an accessibility-tree snapshot of the page DOM

---

## Language Server (Code Intelligence)
- **lsp_diagnostics** — Get TypeScript/JS errors for a file
- **lsp_definition** — Go to definition of a symbol
- **lsp_references** — Find all references to a symbol
- **lsp_hover** — Get type info and docs for a symbol

---

## Documents
- **generate_docx** — Create formatted Word documents from markdown

---

## Planning & Workflow
- **create_plan** — Create a multi-step execution plan
- **add_plan_step** — Add a step to the current plan
- **execute_step** — Mark a step complete with result
- **show_plan** — Show the current plan and step statuses
- **compose_workflow** — Analyze a task and get an execution approach recommendation
- **orchestrate_workflow** — Run a multi-agent workflow (research-team, review-pair, plan-execute)

---

## Sub-Agents
- **spawn_agent** — Spawn a specialist sub-agent (researcher, writer, coder, analyst, reviewer, planner)
- **list_agents** — Show active and completed sub-agents
- **get_agent_result** — Retrieve a completed sub-agent's full result

---

## Skills & Capabilities
- **list_skills** — Show all 56 installed skills
- **create_skill** — Create a new persistent skill
- **delete_skill** — Remove a skill
- **read_skill** — Read a skill's full content
- **search_skills** — Search for capabilities by description
- **suggest_skill** — Get skill recommendations for the current task
- **acquire_capability** — Detect gaps and find installable skills
- **install_capability** — Install a skill from the starter pack (requires your approval)

---

## Scheduling
- **create_schedule** — Create a cron job (e.g., daily memory consolidation)
- **list_schedules** — Show all scheduled jobs
- **delete_schedule** — Remove a schedule
- **trigger_schedule** — Run a schedule immediately

---

**Total: 57 tools + 56 loaded skills.**

The skills extend my behavior with structured workflows — things like `catch-up`, `decision-matrix`, `risk-assessment`, `draft-memo`, `research-team`, and more. Want me to demonstrate any of these?

### **You** *(02:45:40)*

Continue listing. Also list your browser tools, LSP tools, KVARK tools, search tools (tavily, brave), document tools, cron/scheduling tools, and agent communication tools. I need the COMPLETE list.

### **Assistant** *(02:45:50)*

I already gave you the complete list — that was all of it. Let me be precise about what's there and what isn't:

---

## Already Listed (confirmed in previous response)

**Browser tools** — all 6 are there:
`browser_navigate`, `browser_screenshot`, `browser_click`, `browser_fill`, `browser_evaluate`, `browser_snapshot`

**LSP tools** — all 4 are there:
`lsp_diagnostics`, `lsp_definition`, `lsp_references`, `lsp_hover`

**Search tools** — all 4 are there:
`web_search`, `web_fetch`, `tavily_search`, `brave_search`

**Document tools** — 1 is there:
`generate_docx` — this is the only document generation tool I have natively. The `docx`, `word-docx`, `pdf`, `pptx`, `xlsx`, `excel-xlsx` entries are **skills** (structured workflows), not separate tools.

**Scheduling tools** — all 4 are there:
`create_schedule`, `list_schedules`, `delete_schedule`, `trigger_schedule`

---

## What I Do NOT Have

- **KVARK tools** — no tools with that name exist in my toolset. Not installed, not available.
- **Agent communication tools** — no inter-agent messaging, pub/sub, or direct agent-to-agent protocol tools. Sub-agents are spawned and return results, but there's no live communication channel between agents.
- **"Continue listing"** — there is nothing more to list. The previous response was exhaustive.

---

**Hard count: 57 tools total.** If you've seen references to KVARK elsewhere in the Waggle codebase or docs, I can search memory or the repo to find out what it is — but it's not exposed to me as a tool right now.

### **You** *(02:46:33)*

Based on my usage pattern, what capabilities would make me more productive? I'm a software architect who reviews code, designs systems, writes ADRs, and mentors junior developers.

### **Assistant** *(02:46:57)*

Good data. Here's an honest, grounded assessment:

---

## What You Already Have (and it's good)

**`architectural-review-companion`** — you built this yourself. It reviews diffs against your documented conventions, flags violations with 🔴🟡🔵 severity, and saves new patterns to memory. This is your highest-value active skill for code review work.

**`code-review`** — a simpler generic skill, largely superseded by the above.

**`decision-matrix`** — useful for system design tradeoffs. Weighted criteria scoring with a recommendation. Directly applicable to architecture decisions.

**`draft-memo`** + **`drafting-from-context`** — for writing ADRs and documentation from accumulated context.

**`task-breakdown`** — good for breaking down system design work into concrete steps for junior devs.

**`explain-concept`** — adjustable-depth explanations. Directly useful for mentoring.

**`compare-docs`** — side-by-side comparison. Useful for ADR versioning or comparing design proposals.

---

## Gaps Worth Filling

| Gap | What's Missing | Recommendation |
|-----|---------------|----------------|
| **ADR authoring** | No structured ADR skill — you're using generic drafting tools | Create a custom `adr-writer` skill with your team's ADR template baked in |
| **Mentoring feedback** | No skill for generating calibrated, growth-oriented code feedback | Create a `mentoring-feedback` skill with junior-dev tone guidelines |
| **System design documentation** | `draft-memo` is generic — no C4 model, sequence diagram, or component doc workflow | Create a `system-design-doc` skill |
| **Pattern library** | Your architectural patterns live in memory but aren't easily surfaced as a living document | Periodic `save_memory` discipline + a skill that exports patterns to a doc |
| **Review pair workflow** | You have `review-pair` (writer + reviewer sub-agents) but it's not wired to your architectural patterns | Could combine `review-pair` + `architectural-review-companion` |

---

## Three Concrete Suggestions

**1. Build an `adr-writer` skill** — give it your team's ADR template (context, decision, status, consequences). I can create it now based on what I know about your stack and conventions.

**2. Build a `mentoring-feedback` skill** — takes a junior dev's code or question, calibrates depth to their level, gives growth-oriented feedback without doing their work for them. Your `explain-concept` skill is halfway there.

**3. Wire `lsp_diagnostics` into your review workflow** — you have the tool but it's not in any skill. A review that combines `git_diff` + `lsp_diagnostics` + `architectural-review-companion` would catch both style/pattern violations and actual type errors in one pass.

---

Want me to build any of these? The `adr-writer` skill would take about 2 minutes and would immediately improve your ADR output quality.

### **You** *(02:48:52)*

I want to create a new skill called 'Architectural Review Companion'. It reviews code diffs against team conventions, flags architectural conflicts, generates review comments, and saves patterns as memory. Help me design the skill definition file.

### **Assistant** *(02:49:05)*

It's already fully built. Here's the situation:

---

## What You Have

The skill is complete and production-quality. It covers everything you described:

- **Reviews diffs** — accepts pasted diffs, file paths, or runs `git_diff` automatically
- **Flags architectural conflicts** — 10 enforced patterns with 🔴🟡🔵 severity
- **Generates structured review comments** — `📍 file:line → issue → why → fix` format
- **Saves new patterns to memory** — Step 6 of the workflow, with importance tagging
- **Produces a verdict** — APPROVE / REQUEST CHANGES / DISCUSS with a summary block

---

## What's Waggle-Specific In It

The skill is tuned to your stack: TypeScript strict, Fastify 5, Drizzle, BullMQ, sqlite-vec, FTS5 — and enforces Waggle-specific patterns like CognifyPipeline wiring and ConfirmationGate. It's not a generic review skill.

---

## Two Options

**Option A — Use it as-is.** Just say "review current changes" or "review `packages/agent/src/loop.ts`" and it activates.

**Option B — Extend it for your architect role.** Since you're reviewing other teams' code (not just Waggle), I can create a second skill — `adr-writer` or `mentoring-feedback` — that complements this one without duplicating it.

Which direction do you want to go?

### **You** *(02:49:36)*

Save this skill to my skills directory so I can install it. I want to make sure it is properly saved and accessible.

### **Assistant** *(02:50:05)*

Everything is confirmed. Here's the full picture:

---

## Status: Already Done

The skill is **fully saved, properly installed, and active**.

| Property | Value |
|----------|-------|
| **File** | `C:\Users\MarkoMarkovic\.waggle\skills\architectural-review-companion.md` |
| **Size** | 6,650 bytes (largest skill in your directory — it's the most detailed one) |
| **Written** | Today, 21.03.2026 at 02:45 |
| **Loaded** | Yes — it's in your active system prompt right now |
| **Directory** | `C:\Users\MarkoMarkovic\.waggle\skills\` — 57 skills total |

---

## What the File Contains

- Full Waggle architecture baseline (10 enforced patterns)
- 6-step review workflow (get diff → search memory → analyze → comment → summary → save patterns)
- Structured comment format with 🔴🟡🔵 severity
- Checklist covering structural, memory, agent loop, safety, and test checks
- Quick command shortcuts ("review current changes", "review staged changes", etc.)

---

Nothing to install. To use it right now, just say:

> **"Review current changes"** — and it runs `git_diff`, applies all 10 patterns, and produces a verdict.

### **You** *(02:50:49)*

Review the latest commit diff. Run git_diff to get the diff from HEAD~1 and apply your architectural review companion skill. Focus on the source code changes only (skip UAT markdown files).
