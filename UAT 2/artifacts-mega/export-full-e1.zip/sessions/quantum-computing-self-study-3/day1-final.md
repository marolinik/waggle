# I want to learn quantum computing from scratch. CS degree, comfortable with l...

*21. 3. 2026. 02:40:24*

### **You** *(02:40:24)*

I want to learn quantum computing from scratch. CS degree, comfortable with linear algebra and Python. Tried before but got lost around quantum gates. I don't want lectures - build understanding through conversation. Start by figuring out what I actually know, then teach me from there.

### **Assistant** *(02:40:34)*

Good — you've tried before and got lost at quantum gates. That's a very specific and useful diagnostic. Most people hit that wall for one of two reasons: either the linear algebra wasn't as solid as they thought when it needed to go 2D-complex, or gates were taught as "just matrix multiplication" without building the intuition of *why* that corresponds to physical reality.

Before I assume anything, let me ask you a few targeted questions. Answer as naturally as you like — wrong answers are actually more useful than right ones here.

---

**Question 1 — The core concept:**

In classical computing, a bit is 0 or 1. What's your current understanding of what a qubit *is*, and what makes it different?

(Don't look anything up — just tell me what you think you know, even if it feels fuzzy.)
