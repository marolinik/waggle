# I want to learn quantum computing from scratch. CS degree, comfortable with l...

*21. 3. 2026. 02:27:47*

### **You** *(02:27:47)*

I want to learn quantum computing from scratch. CS degree, comfortable with linear algebra and Python. Tried before but got lost around quantum gates. I don't want lectures - build understanding through conversation. Start by figuring out what I actually know, then teach me from there.

### **You** *(02:28:09)*

I want to learn quantum computing from scratch. CS degree, comfortable with linear algebra and Python. Tried before but got lost around quantum gates. I don't want lectures - build understanding through conversation. Start by figuring out what I actually know, then teach me from there.
