# Show me what I know and what I don't know yet based on my learning so far.

*21. 3. 2026. 02:48:42*

### **You** *(02:48:42)*

Show me what I know and what I don't know yet based on my learning so far.

### **Assistant** *(02:48:58)*

Good — I have enough. Here's your honest map based on this session's recorded progress:

---

## What You Know

| Concept | Status | Evidence |
|---|---|---|
| Qubits can be 0 and 1 simultaneously | Solid | You stated this correctly |
| Measurement collapses a qubit | Know it | You were about to answer this before I redirected |
| Superposition exists | Solid | Confirmed |
| Interference / wave analogy | Understood | You followed the maze explanation |
| Why superposition *matters* | Shaky | You said "I still don't get why it matters" |

---

## Where You Got Stuck Before

You've tried quantum computing before and **hit a wall at quantum gates**. Specifically recorded:

> *"Either the linear algebra wasn't as solid as they thought when it needed to go 2D-complex, or gates were taught as 'just matrix multiplication' without building the intuition of why that corresponds to physical reality."*

That's your known failure point from a previous attempt.

---

## What You Haven't Covered Yet

Based on a standard learning path, these are ahead of you:

| Topic | Status |
|---|---|
| Quantum gates (Hadamard, CNOT, Pauli-X) | Not covered — prior sticking point |
| Quantum circuits | Not covered |
| Entanglement | Not covered |
| Why interference is useful (cancellation trick) | Partially — analogy understood, mechanics not done |
| Quantum algorithms (Grover, Shor) | Not covered |
| Bloch sphere / state vector representation | Not covered |
| Linear algebra for QC (complex amplitudes) | Unknown — possibly the wall |

---

## The Gap to Watch

The recorded diagnostic is clear: **gates are where it fell apart before**. The risk is the same now — if we get to gates and teach them as matrices without first building why they work, you'll hit the same wall.

Want to continue from where we left off — specifically nailing *why superposition matters* — so we can bridge cleanly into gates this time?
