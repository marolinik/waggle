# Save each as separate normal importance memory frames:

*20. 3. 2026. 19:52:17*

### **You** *(19:52:17)*

Save each as separate normal importance memory frames:
1. QUESTION: What happens to team structure at 200 staff? Spans of control and middle management.
2. QUESTION: Berlin office before or after Series B? Tax implications unclear.
3. QUESTION: Is current pricing sustainable at enterprise scale? Per-seat vs usage-based analysis needed.
4. QUESTION: Data residency requirements for EU government contracts?
5. QUESTION: Right equity split for advisory board? Luka suggested 0.25% each.
6. QUESTION: Build or buy analytics dashboard? RetailCo needs it Q3.
7. QUESTION: How to retain Aleksandar against Google 40% premium offer?
8. QUESTION: AI ethics framework needed before Ministry contract goes live.
9. QUESTION: ISO 27001 alongside SOC 2 or sequence them?
10. QUESTION: Q3 hiring pace - Stefan wants 8 engineers, budget supports 5.

### **Assistant** *(19:52:46)*

All 10 strategic questions have been saved as separate memory frames. These cover key areas for your growing company:

**Organizational:** Team structure at 200 staff, Berlin office timing, Q3 hiring constraints
**Financial:** Pricing sustainability, advisory equity splits, budget vs. hiring needs  
**Technical:** Build vs. buy decisions, certification sequencing
**Talent:** Aleksandar retention strategy against Google's offer
**Compliance:** Data residency, AI ethics framework, ISO 27001 timing

I notice these questions span multiple critical growth areas - from immediate talent retention to strategic expansion decisions. The Aleksandar retention question seems particularly urgent given the 40% premium offer from Google.
