# Draft an update from what we know

*12. 3. 2026. 13:22:46*

> Draft an update from what we know — 2 messages

### **You** *(13:22:55)*

Draft an update from what we know

### **You** *(02:22:43)*

Whera are we with the project
