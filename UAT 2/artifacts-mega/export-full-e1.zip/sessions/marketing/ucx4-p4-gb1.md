# What did we decide about hiring a CMO?

*20. 3. 2026. 19:54:54*

### **You** *(19:54:54)*

What did we decide about hiring a CMO?

### **Assistant** *(19:55:04)*

Based on your workspace memory, there was a significant change in your CMO hiring decision:

**Initial Decision**: No CMO hire until after Series B fundraise completes

**Updated Decision**: Post CMO role immediately, 60-day close target. Board approved emergency hire to accelerate go-to-market.

The board reversed the original decision and approved an emergency hire to accelerate your go-to-market strategy. You're now actively recruiting for the CMO position with a target to close the hire within 60 days.

This appears to be part of a broader push to scale your marketing and sales efforts, especially given your Series B target of EUR 15M at EUR 80M pre-money valuation that's also in your recent decisions.
