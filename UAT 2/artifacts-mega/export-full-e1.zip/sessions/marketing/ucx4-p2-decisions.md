# Save each of the following as separate memory frames. Use importance "importa...

*20. 3. 2026. 19:50:19*

### **You** *(19:50:19)*

Save each of the following as separate memory frames. Use importance "important" for all:
1. DECISION: Q2 board decided to delay Series B fundraise to Q4 2026 due to market conditions
2. DECISION: Hired Andrej Petrovic as Head of Sales, starting April 1st
3. DECISION: Approved 15% budget increase for engineering team
4. DECISION: Selected Azure over AWS for cloud migration
5. DECISION: No CMO hire until after Series B fundraise completes
6. DECISION: Launched pilot with RetailCo for AI inventory management
7. DECISION: Monthly town halls replacing quarterly format starting April
8. DECISION: University of Ljubljana ML research partnership
9. DECISION: Travel freeze until Q3 budget review
10. DECISION: New Zagreb office lease, 18 months from May 1
11. DECISION: Promoted Jelena Kovac to VP Engineering
12. DECISION: Series B target EUR 15M at EUR 80M pre-money
13. DECISION: Sunset legacy CRM by June 30, migrate to HubSpot
14. DECISION: Formal advisory board with 4 external advisors
15. DECISION: SOC 2 Type II certification target Q3

### **Assistant** *(19:50:59)*

All 15 decisions have been saved as separate important memory frames in your workspace. These strategic decisions are now part of your workspace context and will inform future planning and decision-making discussions.

Key themes I notice from these decisions:
- **Financial strategy**: Series B delayed to Q4, EUR 15M target at EUR 80M pre-money
- **Team expansion**: New Head of Sales (Andrej), VP Engineering promotion (Jelena), 15% engineering budget increase
- **Infrastructure**: Azure cloud migration, new Zagreb office, SOC 2 certification
- **Operations**: Monthly town halls, travel freeze, CRM migration to HubSpot
- **Growth**: RetailCo pilot, University of Ljubljana partnership, advisory board formation
