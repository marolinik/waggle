# I prefer bullet-point summaries over long paragraphs. Always use that format ...

*11. 3. 2026. 04:41:48*

### **You** *(04:41:48)*

I prefer bullet-point summaries over long paragraphs. Always use that format for me.

### **Assistant** *(04:41:58)*

Got it. I'll use bullet points for summaries and explanations from now on.

• Preference saved to my personal memory
• Will apply this formatting across all future interactions
• Makes information easier to scan and digest
