# What do you know about this project?

*11. 3. 2026. 04:17:46*

### **You** *(04:17:46)*

What do you know about this project?

### **Assistant** *(04:18:10)*

Based on my memory, here's what I know about the Waggle project:

## Vision
Waggle is a **personal AI agent swarm platform** — every knowledge worker gets their own AI orchestrator with persistent memory, knowledge graph, and real-world tools. It's an open core model targeting $9-15/user/month for the Pro tier.

## Current Status
We're at **Milestone 3c complete**, with these major achievements:
- **M0 (POC)**: Scientific validation ✓
- **M1 (MVP Desktop)**: Basic Tauri app ✓  
- **M2 (Developer Platform)**: 6 packages, 232 tests ✓
- **M3b (Agent Intelligence)**: Self-awareness, cost tracking ✓
- **M3c (Agent Power)**: Permission system, git tools, planning ✓

## Core Architecture
The breakthrough is the **.mind file** — a single SQLite database containing everything: memory frames, knowledge graph, identity, awareness, sessions, FTS5 search, vector embeddings. Copy the file = copy the brain. Inspired by video codec design with I-frames (snapshots) + P-frames (deltas).

## Tech Stack
Node.js monorepo with 11 packages: @waggle/core, @waggle/agent, @waggle/cli, @waggle/sdk, plus Tauri, TypeScript, better-sqlite3, Drizzle, BullMQ, Clerk auth.

## Next Up
**M4 (Tauri 2.0 Desktop)** for Windows is the active priority, then **M5 (Web App)**. The strategy: build platforms first, polish agent intelligence last — since agent improvements benefit all platforms simultaneously.

## Current Gaps
MockEmbedder in CLI (no real semantic search), no Memory Weaver daemon, basic knowledge graph without SHACL validation.

The codebase lives at `D:\Projects\MS Claw\waggle-poc` — a full monorepo ready for the next milestone.
