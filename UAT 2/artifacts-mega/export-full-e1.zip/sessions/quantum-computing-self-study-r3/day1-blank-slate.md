# I want to learn quantum computing from scratch. CS degree, comfortable with l...

*21. 3. 2026. 02:40:14*

### **You** *(02:40:14)*

I want to learn quantum computing from scratch. CS degree, comfortable with linear algebra and Python. Tried before but got lost around quantum gates. I don't want lectures - build understanding through conversation. Start by figuring out what I actually know, then teach me from there.

### **Assistant** *(02:40:23)*

Good — I have your previous correction: you want to be tested and I should be honest when you're wrong. No coddling.

Let's figure out exactly where you are before teaching you anything.

---

I'll ask you a few questions — just answer in your own words, no looking things up. There are no trick questions here, but I will push back if something's off.

**Question 1 — The core premise:**

In classical computing, a bit is 0 or 1. What's your current understanding of what makes a *qubit* different? What does "superposition" mean to you — in your own words, not a textbook definition?

Take your time. The more honest your answer, the faster we get to the part where things click.
