# What are all the hiring decisions made this month?

*21. 3. 2026. 02:46:01*

### **You** *(02:46:01)*

What are all the hiring decisions made this month?

### **Assistant** *(02:46:09)*

Here are all the hiring decisions from this workspace for March 2026. Note that several of these are marked **deprecated** (potentially outdated — flagged during a prior session), so I'm surfacing them with that caveat:

| Decision | Details | Status |
|---|---|---|
| Hired Andrej Petrovic as Head of Sales | Effective April 1, 280k package with equity | ⚠️ Deprecated |
| Approved budget for Andrej to hire 2 SDRs + 1 AE | Target: end of April | ⚠️ Deprecated |
| Approved hiring of 3 junior developers | To handle increased support load | ⚠️ Deprecated |
| No CMO hire until after Series B | Board agreed unanimously; marketing leadership can wait | ⚠️ Deprecated |

**A note on the deprecated status:** These were flagged as potentially outdated in a prior session — likely because they were part of demo/test data loaded into this workspace. They may not reflect real decisions.

Do you want me to confirm which of these are real, update them, or clear the deprecated ones?
