# Give me a decision log for March 2026.

*21. 3. 2026. 02:51:44*

### **You** *(02:51:44)*

Give me a decision log for March 2026.

### **Assistant** *(02:52:11)*

One flag before I give you the log: **there are conflicts in memory on the CMO decision.** I have three contradictory records:

- **Day 2**: Hire CMO immediately, 350k EUR, Ana Kovac pushed for it
- **Day 4**: No CMO hire until after Series B (board unanimous)
- **Day 4** (second version): Post CMO role immediately, 60-day close — Andrej convinced the team

These need to be reconciled. I'll flag them clearly in the log.

---

## Decision Log — March 2026

| # | Decision | Context / Rationale | Status / Notes |
|---|----------|---------------------|----------------|
| 1 | **Series B delayed to Q4** | Market conditions and investor sentiment | ✅ Confirmed |
| 2 | **B2C → B2B pivot, effective Mar 25** | Product-market fit focus | ✅ Confirmed |
| 3 | **Hired Andrej Petrovic as Head of Sales** | Effective April 1, 280k + equity | ✅ Confirmed |
| 4 | **6-week feature freeze** | Focus on stability and tech debt | ✅ Confirmed |
| 5 | **Marketing budget cut 40%** | Shift from paid acquisition to organic | ✅ Confirmed |
| 6 | **TechCorp partnership signed** | Data processing collaboration, 2 amendments | ✅ Confirmed |
| 7 | **Engineering → 3 squads** | Platform, Product, Growth | ✅ Confirmed |
| 8 | **AWS over Azure for cloud migration** | Cost + team expertise | ✅ Confirmed |
| 9 | **15% salary band increase for senior engineers** | Reduce attrition | ✅ Confirmed |
| 10 | **Company retreat: Dubrovnik, May 15–17** | 45k EUR budget | ✅ Confirmed |
| 11 | **Q3 office expansion cancelled** | Re-evaluate after Series B | ✅ Confirmed |
| 12 | **4-day work week trial, June–August** | Measuring productivity impact | ✅ Confirmed |
| 13 | **Notion over Confluence** | Team familiarity | ✅ Confirmed |
| 14 | **Customer success → Product org** | Reports to VP Product | ✅ Confirmed |
| 15 | **Hired 3 junior devs** | Handle increased support load | ✅ Confirmed |
| 16 | **Bi-weekly board updates** | Dragan's request | ✅ Confirmed |
| 17 | **OKR framework, starting Q2** | Replaces informal goal-setting | ✅ Confirmed |
| 18 | **Mobile app deferred to Q4** | Web PMF first | ✅ Confirmed |
| 19 | **Stripe over Adyen** | Developer experience | ✅ Confirmed |
| 20 | **3 Slack workspaces → 1** | Reorganized by function | ✅ Confirmed |
| 21 | **€200k emergency security audit budget** | After penetration test findings | ✅ Confirmed |
| 22 | **PR agency terminated** | Comms moving in-house | ✅ Confirmed |
| 23 | **Jelena promoted to Staff Engineer** | Effective immediately | ✅ Confirmed |
| 24 | **EU data residency: Frankfurt only** | GDPR compliance | ✅ Confirmed |
| 25 | **Trunk-based development** | Eliminated long-lived feature branches | ✅ Confirmed |
| 26 | **Q2 revenue target: 450k EUR MRR** | Up from 380k | ✅ Confirmed |
| 27 | **2 SDRs + 1 AE for Andrej's team** | By end of April | ✅ Confirmed |
| 28 | **All partnerships paused** | Until after Series B close | ✅ Confirmed |
| 29 | **Usage-based pricing tier added** | Alongside flat monthly plans | ✅ Confirmed |
| 30 | **2% option pool refresh** | Board approved, retention grants | ✅ Confirmed |
| 31 | **3-tier pricing: Starter 49 / Pro 199 / Enterprise custom** | Pricing committee Mar 18 | ✅ Confirmed |
| 32 | **Monorepo architecture** | Nemanja + Marija chose over multi-repo | ✅ Confirmed |
| — | **CMO hire** | ⚠️ **CONFLICT — three contradictory records** | ❓ Needs resolution |

---

### CMO Decision — Conflict to Resolve

| Version | Decision | Source |
|---------|----------|--------|
| Day 2 | Hire CMO immediately, 350k EUR, Ana Kovac pushed for it | memory |
| Day 4 (v1) | No CMO hire until after Series B — board unanimous | memory |
| Day 4 (v2) | Post CMO role immediately, 60-day close — Andrej convinced the team | memory |

Which is the current standing decision? Once you confirm, I'll correct the memory and close the log cleanly.
