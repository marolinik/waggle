# What did we decide about hiring a CMO?

*21. 3. 2026. 02:53:46*

### **You** *(02:53:46)*

What did we decide about hiring a CMO?

### **Assistant** *(02:53:53)*

There's a conflict in memory I need to surface before answering.

I have **three contradictory entries** about the CMO decision:

| Memory | Decision |
|--------|----------|
| Day 2 (active) | **Hire a CMO immediately** — 350k EUR package approved, Ana Kovac pushed for it, search starting next week |
| Day 4 (active) | **No CMO until after Series B** — Board agreed unanimously, budget redirected to engineering hiring |
| Day 4 (deprecated) | Post CMO role immediately, 60-day close target — Andrej convinced the team |

The two **active** memories directly contradict each other. The most recent one (Day 4) says **no CMO hire until after Series B** — which would be the final position if decisions were made chronologically.

**My read:** Day 4 overrides Day 2. The board reversed course — initially approved a CMO hire on Day 2, then walked it back on Day 4, redirecting that budget to engineering.

But you should confirm: is the Day 4 "no CMO" decision the current standing position? If so, I'll deprecate the Day 2 entry so this doesn't keep creating confusion.
