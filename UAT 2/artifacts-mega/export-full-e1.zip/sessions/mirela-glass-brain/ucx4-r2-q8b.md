# Who are my 5 most important external relationships right now?

*21. 3. 2026. 02:52:37*

### **You** *(02:52:37)*

Who are my 5 most important external relationships right now?

### **Assistant** *(02:52:58)*

I need to be straight with you: I don't have enough captured in this workspace to answer this confidently.

Here's what I do have:

**Named external people in memory:**
- **Ana Kovac** — Board member, was the primary advocate for the CMO hire. Active voice in strategic decisions.
- **Andrej** — Appears in the decision log, convinced the board to post the CMO role (Day 4 reversal). Board-level influence.
- **Milos** — Flagged the 85% Q1 budget burn. Finance function, likely CFO or financial controller.
- **RivalTech team** — Open question in your notes: acqui-hire vs. individual hires. Relationship status and importance unclear.

**What's unclear:**
- Your investors are referenced (Series B context) but no investor names are captured.
- No customers, key prospects, or partners are named in this workspace.
- The "CEO shut down company March 31" decision is captured — depending on whether that's real or a test entry, the entire relationship landscape changes.

**The honest answer:** I can see fragments of ~4 people, but I don't have enough captured about your full external relationship map to rank your top 5 reliably.

Two options:
1. **Tell me** — walk me through your top relationships and I'll capture them properly so I can answer this intelligently in the future.
2. **Let me check another workspace** — if you've logged more relationship context elsewhere (investor meetings, customer interactions), I can search across workspaces.

Which do you want to do?
