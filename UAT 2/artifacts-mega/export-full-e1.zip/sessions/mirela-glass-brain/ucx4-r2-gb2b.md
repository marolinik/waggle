# What was that thing I said about the board?

*21. 3. 2026. 02:54:19*

### **You** *(02:54:19)*

What was that thing I said about the board?

### **Assistant** *(02:54:25)*

There are actually three distinct board-related things in memory — and they conflict with each other:

1. **Day 2**: Board approved hiring a CMO immediately — 350k EUR package, Ana Kovac pushed for it, search starting the following week.
2. **Day 4**: Board reversed course — no CMO until after Series B. Unanimous. Budget redirected to engineering hiring.
3. **Q2 board meeting**: Decided to delay Series B to Q4 due to market conditions.

The CMO decision is the interesting one — it flipped between Day 2 and Day 4. Which one were you thinking of?
