# What are my own open questions - things I said I need to think about?

*21. 3. 2026. 02:51:02*

### **You** *(02:51:02)*

What are my own open questions - things I said I need to think about?

### **Assistant** *(02:51:19)*

Here's the complete list of your own open questions — things you explicitly said you need to think about. Note that several are marked **deprecated** (flagged as potentially outdated), but I'm including them since you asked for everything you said:

---

## Your Open Questions

**Strategic / Organizational**
- Should you **acqui-hire the RivalTech team** or just hire their engineers individually?
- Do we need a **dedicated CISO** vs. keeping security under the CTO?
- What happens when we hit **200 staff** — do we need a COO or restructure into business units?
- Should we **open-source the SDK** to drive developer adoption?

**Personal / Leadership**
- You're spending **60% of your time in meetings and only 20% on strategic thinking** — need to fix this.
- Need to **build stronger relationships with the engineering team** — you noted feeling disconnected.
- You need to **say no to more things** — every yes is a no to something else.

---

**Caveat:** The organizational ones (CISO, RivalTech, COO, SDK) are from the Mirela Glass Brain workspace context and are marked deprecated — meaning they may have been resolved or overtaken by events. The personal/leadership reflections were logged by you directly.

Want me to do a quick audit — go through each one and you tell me if it's still open, resolved, or no longer relevant? I can update the records cleanly.
