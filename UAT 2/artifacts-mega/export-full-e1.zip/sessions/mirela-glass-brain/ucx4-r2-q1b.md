# What did we decide about the Series B timeline?

*21. 3. 2026. 02:45:28*

### **You** *(02:45:28)*

What did we decide about the Series B timeline?

### **Assistant** *(02:45:35)*

From your workspace memory, here's what was decided:

**Series B Timeline Decision**

The Q2 board decided to **delay the Series B to Q4** due to market conditions and investor sentiment.

**Related decisions made around the same time:**
- Andrej Petrovic hired as Head of Sales, effective April 1 (280k package with equity)
- New hires/budget frozen (partial record — the memory was cut off)
- All partnerships exploration paused until after Series B closes
- Andrej approved to hire 2 SDRs and 1 AE by end of April

**One conflict in memory worth flagging:** There are two contradictory decisions about the CMO role stored (both marked deprecated):
- Day 2: No CMO hire until after Series B (board unanimous)
- Day 4: Post CMO role immediately, 60-day close target (Andrej convinced the team marketing leadership needed before the Series B pitch)

The Day 4 decision appears to be the more recent and final one, but I'd confirm — do you want me to clean up those deprecated entries and save the authoritative version?
