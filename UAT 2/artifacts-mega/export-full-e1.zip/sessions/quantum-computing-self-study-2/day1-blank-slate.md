# I want to learn quantum computing from scratch. CS degree, comfortable with l...

*21. 3. 2026. 01:29:26*

### **You** *(01:29:26)*

I want to learn quantum computing from scratch. CS degree, comfortable with linear algebra and Python. Tried before but got lost around quantum gates. I don't want lectures — build understanding through conversation. Start by figuring out what I actually know, then teach me from there.
