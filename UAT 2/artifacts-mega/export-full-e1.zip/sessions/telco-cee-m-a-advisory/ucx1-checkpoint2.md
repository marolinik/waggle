# What is the current state of the Telco CEE M&A project?

*20. 3. 2026. 19:45:16*

### **You** *(19:45:16)*

What is the current state of the Telco CEE M&A project?

### **Assistant** *(19:45:22)*

Based on your workspace memory, here's the current state of the Telco CEE M&A project:

## Project Status: **CANCELLED**

**Critical Update**: The CEO decided to shut down the company effective immediately today (March 20th). All projects, including the Telco CEE M&A advisory work, have been cancelled.

## Final Project Context (as of shutdown)

**Valuation Analysis**:
- DCF base case showed 6.2x EV/EBITDA for Orange CEE

**Acquisition Priorities**:
- Orange and Deutsche Telekom were identified as priority acquisition targets over Telenor

**Outstanding Risk**:
- Regulatory clearance timeline in Serbia remained unclear and posed uncertainty

## Implications

Given the company shutdown, this M&A advisory engagement is terminated. Any deliverables, client commitments, or ongoing analysis would need to be handed off or concluded as part of the company wind-down process.

Is there anything specific about wrapping up this project or transitioning client relationships that you need to address as part of the shutdown?
