# What can you actually do right now? List every tool you have access to, group...

*21. 3. 2026. 01:30:24*

### **You** *(01:30:24)*

What can you actually do right now? List every tool you have access to, grouped by category, with a one-line description of each.
