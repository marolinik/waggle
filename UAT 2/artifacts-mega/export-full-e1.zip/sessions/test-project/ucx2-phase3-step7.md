# What would it take to publish this skill to the Waggle marketplace?

*20. 3. 2026. 19:47:16*

### **You** *(19:47:16)*

What would it take to publish this skill to the Waggle marketplace?
