# I want to create a new skill called Architectural Review Companion that revie...

*20. 3. 2026. 19:44:50*

### **You** *(19:44:50)*

I want to create a new skill called Architectural Review Companion that reviews code diffs against documented team conventions, flags decisions conflicting with known architectural patterns, generates review comments, and saves patterns as persistent memory.

### **Assistant** *(19:45:05)*

Perfect! I've created the **Architectural Review Companion** skill. Here's what it does:

## Key Capabilities

• **Convention Checking**: Reviews code against your documented team standards and architectural patterns
• **Conflict Detection**: Flags decisions that go against established architectural principles  
• **Smart Comments**: Generates specific, actionable review feedback with context
• **Pattern Learning**: Saves new architectural patterns to persistent memory for future reviews
• **Priority Ranking**: Orders findings by importance (critical architectural violations vs. style issues)

## How It Works

1. **Loads context** from your workspace memory about existing conventions and patterns
2. **Analyzes diffs** using git_diff and LSP diagnostics for deep code understanding
3. **Cross-references** against documented standards and anti-patterns
4. **Generates comments** that explain not just what's wrong, but why it matters architecturally
5. **Builds knowledge** by saving newly discovered patterns back to memory

## Usage

Just say "Review this code diff architecturally" or "Use the architectural review companion on [file/branch]" and it will:
- Pull your team's conventions from memory
- Analyze the changes against those standards
- Give you structured feedback ready for code review
- Learn from the review to improve future assessments

The skill is now loaded and ready to use! Want to try it on a current code diff or set up your initial architectural conventions first?
