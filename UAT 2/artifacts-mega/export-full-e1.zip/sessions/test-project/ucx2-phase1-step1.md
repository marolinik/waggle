# What can you actually do right now? List every tool you have access to, group...

*20. 3. 2026. 19:42:43*

> What can you actually do right now — 4 messages · decisions

### **You** *(19:42:43)*

What can you actually do right now? List every tool you have access to, grouped by category, with a one-line description of each.

### **You** *(19:42:55)*

What can you actually do right now? List every tool you have access to, grouped by category, with a one-line description of each.

### **Assistant** *(19:43:09)*

Based on my current capabilities, here are all the tools I have access to, organized by category:

## Memory & Knowledge Management
- **get_identity**: Get my agent identity and role information
- **get_awareness**: Check my current awareness state (active tasks, recent actions, pending items)
- **search_memory**: Search through my persistent memory for past experiences and knowledge
- **save_memory**: Save new memories to either workspace or personal mind
- **query_knowledge**: Query my knowledge graph for entities and their relationships
- **correct_knowledge**: Correct or invalidate knowledge entities in my graph
- **add_task**: Add tasks to my awareness layer for tracking

## File System & Code
- **read_file**: Read contents of files (supports line numbers, offset/limit for partial reads)
- **write_file**: Create or overwrite files with new content
- **edit_file**: Replace exact strings in files (surgical edits)
- **search_files**: Find files using glob patterns
- **search_content**: Search file contents using regex patterns with context
- **multi_edit**: Apply multiple file edits atomically across one or more files

## System & Shell
- **bash**: Execute shell commands in the workspace directory
- **get_task_output**: Get output from background tasks started with run_in_background
- **kill_task**: Kill running background tasks

## Git Version Control
- **git_status**: Show git status (modified/untracked files and current branch)
- **git_diff**: Show git diff (unstaged or staged changes)
- **git_log**: Show recent git commit history
- **git_commit**: Stage files and create atomic git commits

## Web Research
- **web_search**: Search DuckDuckGo for current information
- **web_fetch**: Fetch and extract text content from any URL
- **tavily_search**: AI-optimized search using Tavily (requires API key)
- **brave_search**: Search using Brave API with freshness filtering (requires API key)

## Browser Automation
- **browser_navigate**: Navigate to URLs and get page info
- **browser_screenshot**: Take screenshots of current page (viewport or full page)
- **browser_click**: Click elements using CSS selectors
- **browser_fill**: Fill input fields with values
- **browser_evaluate**: Execute JavaScript in the page context
- **browser_snapshot**: Get simplified DOM snapshot of current page

## Document Generation
- **generate_docx**: Create formatted Word documents from markdown content

## Planning & Project Management
- **create_plan**: Create new execution plans for complex tasks
- **add_plan_step**: Add steps to current plan
- **execute_step**: Mark plan steps as complete with results
- **show_plan**: Display current plan with step statuses

## Skills & Capabilities
- **list_skills**: Show all installed skills and plugins
- **create_skill**: Create new reusable skills from workflow descriptions
- **delete_skill**: Remove installed skills by name
- **read_skill**: Read full content of installed skills
- **search_skills**: Search for skills and suggest built-in capabilities
- **suggest_skill**: Get skill recommendations based on current context
- **acquire_capability**: Detect capability gaps and find installable skills
- **install_capability**: Install capabilities identified by acquire_capability

## Automation & Scheduling
- **create_schedule**: Create new cron schedules for recurring tasks
- **list_schedules**: Show all cron schedules with next run times
- **delete_schedule**: Remove cron schedules by name
- **trigger_schedule**: Manually run scheduled jobs immediately

## Language Server (Code Intelligence)
- **lsp_diagnostics**: Get TypeScript/JavaScript errors and warnings
- **lsp_definition**: Go to symbol definitions in code
- **lsp_references**: Find all references to symbols
- **lsp_hover**: Get type information and documentation for symbols

## CLI Tools Integration
- **cli_discover**: Discover available CLI tools on the system
- **cli_execute**: Execute allowed CLI programs with arguments

## Multi-Agent Orchestration
- **spawn_agent**: Create specialist sub-agents for autonomous task handling
- **list_agents**: Show active and completed sub-agents with status
- **get_agent_result**: Get full results from completed sub-agents
- **compose_workflow**: Analyze tasks and recommend execution approaches
- **orchestrate_workflow**: Run multi-agent workflows (research-team, review-pair, plan-execute)

I'm currently running in your home directory (`C:\Users\MarkoMarkovic`) with no specific workspace set. I have 71 memories from previous sessions and 56 knowledge entities in my graph. I can remember our conversations, learn from interactions, and build knowledge over time.

What would you like me to help you with using these capabilities?

### **Assistant** *(19:43:25)*

Here are all the tools I currently have access to, organized by category:

## Memory & Knowledge
- **get_identity** — Get my agent identity (who I am, what my role is)
- **get_awareness** — Get current awareness state (active tasks, recent actions, pending items)
- **search_memory** — Search through my persistent memory for past experiences and knowledge
- **save_memory** — Save new memories to either workspace or personal mind
- **query_knowledge** — Query the knowledge graph for entities and their relationships
- **correct_knowledge** — Correct or invalidate knowledge entities in the graph

## File System & Content
- **read_file** — Read contents of files (supports partial reads and line numbers)
- **write_file** — Create or overwrite files with new content
- **edit_file** — Replace exact strings in files (surgical edits)
- **search_files** — Find files using glob patterns
- **search_content** — Search file contents using regex patterns
- **multi_edit** — Apply multiple file edits atomically across one or more files

## System & Command Line
- **bash** — Execute shell commands in the workspace directory
- **get_task_output** — Get output and status of background tasks
- **kill_task** — Kill running background tasks
- **cli_discover** — Discover available CLI tools on the system
- **cli_execute** — Execute CLI programs (only allowlisted ones)

## Web & Research
- **web_search** — Search the web using DuckDuckGo for current information
- **web_fetch** — Fetch and extract text content from any web page
- **tavily_search** — Search using Tavily AI (requires API key)
- **brave_search** — Search using Brave API with freshness filtering (requires API key)

## Browser Automation
- **browser_navigate** — Navigate browser to a URL
- **browser_screenshot** — Take screenshots of current browser page
- **browser_click** — Click elements on page using CSS selectors
- **browser_fill** — Fill input elements with values
- **browser_evaluate** — Execute JavaScript in browser context
- **browser_snapshot** — Get simplified DOM snapshot of current page

## Git Version Control
- **git_status** — Show git status (modified/untracked files and current branch)
- **git_diff** — Show git diff (unstaged or staged changes)
- **git_log** — Show recent git commit history
- **git_commit** — Stage files and create atomic git commits

## Language Server (Code Analysis)
- **lsp_diagnostics** — Get TypeScript/JavaScript errors and warnings
- **lsp_definition** — Go to definition of symbols at given positions
- **lsp_references** — Find all references to symbols
- **lsp_hover** — Get type information and documentation for symbols

## Planning & Task Management
- **add_task** — Add tasks to my awareness layer for tracking
- **create_plan** — Create new execution plans
- **add_plan_step** — Add steps to current plan
- **execute_step** — Mark plan steps complete with results
- **show_plan** — Show current plan with step statuses

## Document Generation
- **generate_docx** — Generate formatted Word documents from markdown content

## Skills & Capabilities
- **list_skills** — List all installed skills and plugins
- **create_skill** — Create new reusable skills from workflows
- **delete_skill** — Delete installed skills by name
- **read_skill** — Read full content of installed skills
- **search_skills** — Search for capabilities in installed skills
- **suggest_skill** — Get contextual skill recommendations
- **acquire_capability** — Detect capability gaps and find installable skills
- **install_capability** — Install capabilities identified by acquire_capability

## Scheduling & Automation
- **create_schedule** — Create new cron schedules for recurring tasks
- **list_schedules** — List all cron schedules with status
- **delete_schedule** — Delete cron schedules by name
- **trigger_schedule** — Manually trigger scheduled jobs

## Multi-Agent Coordination
- **spawn_agent** — Spawn specialist sub-agents for autonomous task handling
- **list_agents** — List active and completed sub-agents
- **get_agent_result** — Get full results from completed sub-agents
- **compose_workflow** — Analyze tasks and recommend execution approaches
- **orchestrate_workflow** — Run multi-agent workflows with coordinated specialists

I have **56 specialized skills loaded** covering areas like research synthesis, document drafting, risk assessment, competitive analysis, meeting prep, decision matrices, and many more. These skills provide structured workflows for complex tasks.

**What makes me different:** I have persistent memory across sessions, can spawn specialist sub-agents, and get smarter over time by saving context and learning from our interactions.
